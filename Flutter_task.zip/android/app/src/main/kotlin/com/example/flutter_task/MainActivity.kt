package com.example.flutter_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
