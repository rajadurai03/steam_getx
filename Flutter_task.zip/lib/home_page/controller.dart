import 'dart:async';
import 'dart:convert';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'model.dart';

class HomePageController extends GetxController {
  StreamController<SearchResult> userController;

  @override
  void onInit() {
    streamdata();
    super.onInit();
  }

  Future streamdata() async{
    var response = await http.post('http://balram.twics.in/api/announcements?lang=1',
    headers: {
      "Accept":"application/json",
      "Authorization":"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjY4MjA5YTE3YjAyN2FkZmEyYzlhM2FlYjUyNGYyN2ViYWI0ODdiZTk0MWVkZWUxYjdhNTQ1OGY2OWQ4NWIzMjlmNTU0NGY2ODBlYmI3OTExIn0.eyJhdWQiOiIxIiwianRpIjoiNjgyMDlhMTdiMDI3YWRmYTJjOWEzYWViNTI0ZjI3ZWJhYjQ4N2JlOTQxZWRlZTFiN2E1NDU4ZjY5ZDg1YjMyOWY1NTQ0ZjY4MGViYjc5MTEiLCJpYXQiOjE2NDAwODcyNjAsIm5iZiI6MTY0MDA4NzI2MCwiZXhwIjoxNjcxNjIzMjYwLCJzdWIiOiI0NjQxNjQiLCJzY29wZXMiOltdfQ.BsOlrN9tmSqmX62o1Z5cX-TT798Ct-SOIdo1ljIhK3iF4KpMlleBqs_OnMcxarB0dmH-o2wmURADHTVnPBqcSxpWg5SsYt544ux0OPi9Ymmk0RvUR-6mSXx5NY49vowFS7MoNFCKWV3MLUuoxHQhf1xrlaK9w3ap8AUsIj7oPM-bdhnV19zmnAK9wv7OJ2vntYU7B53bzk4Um6F5rIG1axrKLGRfJUJGSfQVWWEJn7wcUnj4CLo8qU7vHXrPMcwKZiBGb5S5keKhWmM2yz4c_4DaCGm8E8ad-AbbLvphJiuqhKyrMfSegzo0j2rG9-gSXdlnUN7Ro80cwOL8Y33bQJiec83zZmZTJfpIS_PKH5m9gV4ChJ1sOGW92L0uaiZ7_eBfHXLIqAqoDbE_9o9TOwk7xxV2q8T24CrUFZcf_c9OOi3pIksDlGiYZwp0C6uV7e_yYM4MXHrZg-_N4n_PZkdspvhYeBadEwdr748B6OW3EmVKp3d992__xQ3-Lmhp_1tguYOQQ2CMFSqgH_xvjwwAqhLwTNMEAe_jRyGk21iJiZEVnXE1XI56NmM6lMxs6OsRJWB2vW8O6a-Fjn7nV9hvhIIqNECqsVijlBY0BsiyTrgjIaPj_C14ycEXQv_zW6FrLWJAI2U8c8k58-JDkbU1On1JhpRep4sqYuNvgfI"
    },
    );
    if(response.statusCode !=200){
      return Future.error(response.statusCode);
    }
    else{
   var jsonResponse = json.decode(response.body);
   SearchResult enddata= SearchResult.fromJson(jsonResponse);
      return enddata;
    }
  }

  Future loadDetails() async {
    HomePageController().streamdata().then((res) async{
      userController.add(res);
      return res;
    });
  }
}